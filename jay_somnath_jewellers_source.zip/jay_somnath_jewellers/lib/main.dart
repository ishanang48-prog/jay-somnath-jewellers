import 'package:flutter/material.dart';

void main() => runApp(const JaySomnathApp());

const gold = Color(0xFFD4AF37);

class JaySomnathApp extends StatelessWidget {
  const JaySomnathApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Jay Somnath Jewellers',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFF111111)),
    home: const StoreHome(),
  );
}

class StoreHome extends StatelessWidget {
  const StoreHome({super.key});
  static const categories = ['Gold Jewellery','Silver Jewellery','Diamond Jewellery','Gold Rings','Silver Rings','Chains','Bangles','Mangalsutra','Payal','Necklaces','Silver Frames','Silver Utensils'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('JS  JAY SOMNATH JEWELLERS', style: TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 16)), actions: [IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage())), icon: const Icon(Icons.admin_panel_settings_outlined))]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(border: Border.all(color: gold), borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF292216), Color(0xFF111111)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('TIMELESS ELEGANCE', style: TextStyle(color: gold, letterSpacing: 3)), SizedBox(height: 10), Text('Jewellery for Every Occasion', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Discover our collection of gold, silver and diamond jewellery.')]),),
      const SizedBox(height: 22), const Text('SHOP BY CATEGORY', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.5)), const SizedBox(height: 12),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: categories.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.8, crossAxisSpacing: 10, mainAxisSpacing: 10), itemBuilder: (context, i) => Container(alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFF242424), border: Border.all(color: gold.withValues(alpha: .55)), borderRadius: BorderRadius.circular(12)), child: Text(categories[i], textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)))),
      const SizedBox(height: 24), const Text('Visit Our Store', style: TextStyle(color: gold, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('Clifton Building, M.G. Road, Ghogha Gate, Bhavnagar, Gujarat, India'), const SizedBox(height: 6), const Text('WhatsApp: 8320982935'), const SizedBox(height: 18), const Text('Prices and product availability will be updated by the store admin.', style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]),
  );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Admin Login')), body: Padding(padding: const EdgeInsets.all(20), child: Column(children: const [Text('Owner / Manager', style: TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 20), TextField(decoration: InputDecoration(labelText: 'Mobile number', border: OutlineInputBorder())), SizedBox(height: 12), TextField obscureText: true, decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder())), SizedBox(height: 16), Text('Login and OTP authentication will be connected in the production backend.'), SizedBox(height: 12), FilledButton(onPressed: null, child: Text('Continue'))])));
}
